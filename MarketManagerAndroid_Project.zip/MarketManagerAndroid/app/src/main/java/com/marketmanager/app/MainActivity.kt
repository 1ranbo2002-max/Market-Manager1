package com.marketmanager.app

import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.JavascriptInterface
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import java.util.concurrent.Executor

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private lateinit var executor: Executor
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        executor = ContextCompat.getMainExecutor(this)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(BiometricBridge(), "AndroidBiometric")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }
    inner class BiometricBridge {
        @JavascriptInterface fun authenticate() { runOnUiThread { authenticateWithDevice() } }
    }
    private fun authenticateWithDevice() {
        val manager = BiometricManager.from(this)
        val authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL
        if (manager.canAuthenticate(authenticators) != BiometricManager.BIOMETRIC_SUCCESS) {
            web.evaluateJavascript("onNativeBiometricError('البصمة أو قفل الشاشة غير مهيأ على الهاتف')", null)
            return
        }
        val prompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { web.evaluateJavascript("onNativeBiometricSuccess()", null) }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) { web.evaluateJavascript("onNativeBiometricError(${org.json.JSONObject.quote(errString.toString())})", null) }
            override fun onAuthenticationFailed() { web.evaluateJavascript("onNativeBiometricError('لم يتم التعرف على البصمة')", null) }
        })
        val info = BiometricPrompt.PromptInfo.Builder().setTitle("تأكيد الهوية").setSubtitle("استخدم بصمة الهاتف أو قفل الشاشة").setAllowedAuthenticators(authenticators).build()
        prompt.authenticate(info)
    }
}
